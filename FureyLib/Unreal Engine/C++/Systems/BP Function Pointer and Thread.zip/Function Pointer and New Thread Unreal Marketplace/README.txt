BLUEPRINT FUNCTION POINTER AND THREAD OBJECT

A simple but powerful collection of easy-to-use blueprints that enable management of functions and new threads.


INCLUDES:

6 Files - 3 .h files and 3 .cpp files each corresponding with each other.

UFunctionPointer - A blueprintable object that stores a delegate. Can be bound and invoked across different objects like a function pointer.

FAsyncThread - A simple implementation of FRunnable that allows creation of a new thread via a function pointer (C++ only).

UThread - A blueprintable object that manages a newly created asynchronous thread (via a wrapper of FAsyncThread). Can be started later and even programmed to be stopped. 


SOME IMPORTANT NOTES:

- Your project must be able to compile C++ for these scripts to work and appear in blueprints. You must replace the MYGAME_API macro in the .h files with YOURGAME_API.

- All .h files should be directly in /Source/ProjectName/Public and all .cpp files should be directly in /Source/ProjectName/Private. You may need to update the #include path of the scripts if you want to move them.

- Just like infinite loops in the main thread, infinite loops in a new thread are forcefully cancelled after some time if they are not delayed. Do not use new threads to create infinite loops as it will overload the CPU.

- The Stop() method does not forcefully stop a new thread. Just like normal multithreading, you need to program logic to check if the thread is cancelled using IsStopped() in order to determine when to end the thread. You can always check if a thread is running with the IsRunning() method. If you have a long loop, you should check each it loop iteration.


Of course, this library isn't anything groundbreakingly new, but it provides an easy to use interface within blueprints for features previously exclusive to C++.

I learned Unreal C++ by making these tools and found it remarkably easy to implement them into blueprints, and so I wanted to share them here!


Happy multithreading!

- Kyle Furey
