Multi-colored outline post process for Unreal Engine 4.

Add the Content folder to your project (There should already be a folder named Content)

more info and instructions: http://www.tomlooman.com/multi-colored-outline-fx/

By Tom Looman.